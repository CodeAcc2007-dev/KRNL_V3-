import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { BottomNav } from "./components/BottomNav";
import { InboxScreen } from "./components/InboxScreen";
import { DeadlinesScreen } from "./components/DeadlinesScreen";
import { AskKrnlScreen } from "./components/AskKrnlScreen";
import { SettingsScreen } from "./components/SettingsScreen";

type Screen = "inbox" | "deadlines" | "ask" | "settings";

const screenOrder: Screen[] = ["inbox", "ask", "deadlines", "settings"];

function getDirection(from: Screen, to: Screen): number {
  const fromIdx = screenOrder.indexOf(from);
  const toIdx = screenOrder.indexOf(to);
  return toIdx > fromIdx ? 1 : -1;
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>("inbox");
  const [prevScreen, setPrevScreen] = useState<Screen>("inbox");
  const [direction, setDirection] = useState(0);

  const navigate = (screen: Screen) => {
    if (screen === activeScreen) return;
    setDirection(getDirection(activeScreen, screen));
    setPrevScreen(activeScreen);
    setActiveScreen(screen);
  };

  const variants = {
    enter: (dir: number) => ({
      x: dir > 0 ? "100%" : "-100%",
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (dir: number) => ({
      x: dir > 0 ? "-100%" : "100%",
      opacity: 0,
    }),
  };

  return (
    <div
      className="flex items-center justify-center min-h-screen w-full"
      style={{ background: "#050507" }}
    >{/* MARKER-MAKE-KIT-INVOKED */}
      {/* Mobile frame */}
      <div
        className="relative overflow-hidden"
        style={{
          width: 390,
          height: 844,
          background: "#08090a",
          borderRadius: 44,
          boxShadow:
            "0 0 0 1px #2d2d34, 0 40px 100px rgba(0,0,0,0.85), inset 0 0 0 1px rgba(255,255,255,0.04)",
          position: "relative",
        }}
      >
        {/* Status bar notch area */}
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 z-50"
          style={{
            width: 126,
            height: 34,
            background: "#08090a",
            borderRadius: "0 0 18px 18px",
          }}
        />

        {/* Status bar time */}
        <div
          className="absolute top-3 left-6 z-40"
          style={{ color: "#f7f8f8", fontSize: 15, fontWeight: 600 }}
        >
          9:41
        </div>

        {/* Status bar icons */}
        <div className="absolute top-3 right-5 z-40 flex items-center gap-1.5">
          {/* Signal bars */}
          <div className="flex items-end gap-0.5">
            {[3, 5, 7, 9].map((h, i) => (
              <div
                key={i}
                style={{
                  width: 3,
                  height: h,
                  borderRadius: 1.5,
                  background: i < 3 ? "#f7f8f8" : "rgba(247,248,248,0.35)",
                }}
              />
            ))}
          </div>
          {/* WiFi */}
          <svg width="15" height="12" viewBox="0 0 15 12" fill="none">
            <path d="M7.5 10.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" fill="#f7f8f8" />
            <path
              d="M4.5 8.5c.8-.8 1.9-1.3 3-1.3s2.2.5 3 1.3"
              stroke="#f7f8f8"
              strokeWidth="1.5"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M1.8 5.8C3.3 4.3 5.3 3.5 7.5 3.5s4.2.8 5.7 2.3"
              stroke="#f7f8f8"
              strokeWidth="1.5"
              strokeLinecap="round"
              fill="none"
            />
          </svg>
          {/* Battery */}
          <div className="flex items-center gap-0.5">
            <div
              style={{
                width: 22,
                height: 11,
                border: "1.5px solid rgba(247,248,248,0.6)",
                borderRadius: 3,
                padding: 1.5,
                position: "relative",
              }}
            >
              <div
                style={{
                  width: "80%",
                  height: "100%",
                  background: "#f7f8f8",
                  borderRadius: 1,
                }}
              />
              <div
                style={{
                  position: "absolute",
                  right: -4,
                  top: "50%",
                  transform: "translateY(-50%)",
                  width: 2.5,
                  height: 5,
                  background: "rgba(247,248,248,0.5)",
                  borderRadius: "0 1px 1px 0",
                }}
              />
            </div>
          </div>
        </div>

        {/* Screen content */}
        <div className="absolute inset-0 overflow-hidden">
          <AnimatePresence custom={direction} initial={false} mode="popLayout">
            <motion.div
              key={activeScreen}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ type: "spring", stiffness: 340, damping: 35, mass: 0.8 }}
              className="absolute inset-0"
            >
              {activeScreen === "inbox" && (
                <InboxScreen onOpenSettings={() => navigate("settings")} />
              )}
              {activeScreen === "deadlines" && <DeadlinesScreen />}
              {activeScreen === "ask" && <AskKrnlScreen />}
              {activeScreen === "settings" && <SettingsScreen />}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Home indicator */}
        <div
          className="absolute bottom-2 left-1/2 -translate-x-1/2 z-50"
          style={{
            width: 134,
            height: 5,
            background: "rgba(247,248,248,0.25)",
            borderRadius: 100,
          }}
        />

        {/* Global Bottom Nav */}
        <BottomNav activeScreen={activeScreen} onNavigate={navigate} />
      </div>
    </div>
  );
}
