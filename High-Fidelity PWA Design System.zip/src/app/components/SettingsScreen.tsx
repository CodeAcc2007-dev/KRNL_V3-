import { useState } from "react";
import { Plus, RefreshCw, Mail, ChevronRight, AlertTriangle, Info, Shield, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const tracks = ["Software", "Quant", "Research", "Core", "Design", "Finance"];

// Google "G" SVG logo
function GoogleIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
    </svg>
  );
}

export function SettingsScreen() {
  const [selectedTracks, setSelectedTracks] = useState<string[]>(["Software", "Research"]);
  const [showDangerConfirm, setShowDangerConfirm] = useState(false);
  const [googleConnected, setGoogleConnected] = useState(false);
  const [googleConnecting, setGoogleConnecting] = useState(false);

  const toggleTrack = (track: string) => {
    setSelectedTracks((prev) =>
      prev.includes(track) ? prev.filter((t) => t !== track) : [...prev, track]
    );
  };

  const handleGoogleSignIn = () => {
    if (googleConnected) return;
    setGoogleConnecting(true);
    setTimeout(() => {
      setGoogleConnecting(false);
      setGoogleConnected(true);
    }, 1600);
  };

  return (
    <div className="flex flex-col h-full" style={{ background: "#08090a" }}>
      <div style={{ paddingTop: 48 }} className="flex-shrink-0">
        {/* Header */}
        <div className="px-4 pb-4">
          <span style={{ color: "#f7f8f8", fontSize: 20, fontWeight: 700, display: "block" }}>
            Settings & Connections
          </span>
          <span style={{ color: "#8a8f98", fontSize: 13, marginTop: 2, display: "block" }}>
            Manage your accounts and preferences
          </span>
        </div>
        <div style={{ height: 1, background: "#2d2d34", margin: "0 16px 16px" }} />
      </div>

      <div
        className="flex-1 overflow-y-auto px-4"
        style={{ scrollbarWidth: "none", paddingBottom: 110 }}
      >
        {/* Google Sign-In Block */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <GoogleIcon size={13} />
            <span style={{ color: "#8a8f98", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Google Login
            </span>
          </div>

          <AnimatePresence mode="wait">
            {!googleConnected ? (
              <motion.button
                key="sign-in"
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGoogleSignIn}
                disabled={googleConnecting}
                className="w-full flex items-center justify-center gap-3 py-4"
                style={{
                  background: googleConnecting ? "rgba(66,133,244,0.08)" : "#1c1c21",
                  border: googleConnecting
                    ? "1px solid rgba(66,133,244,0.35)"
                    : "1px solid #2d2d34",
                  borderRadius: 16,
                  cursor: googleConnecting ? "not-allowed" : "pointer",
                }}
              >
                {googleConnecting ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 0.9, repeat: Infinity, ease: "linear" }}
                      style={{
                        width: 18,
                        height: 18,
                        borderRadius: "50%",
                        border: "2px solid rgba(66,133,244,0.25)",
                        borderTopColor: "#4285F4",
                      }}
                    />
                    <span style={{ color: "#8a8f98", fontSize: 14, fontWeight: 500 }}>
                      Signing in…
                    </span>
                  </>
                ) : (
                  <>
                    <GoogleIcon size={20} />
                    <span style={{ color: "#f7f8f8", fontSize: 14, fontWeight: 600 }}>
                      Sign in with Google
                    </span>
                  </>
                )}
              </motion.button>
            ) : (
              <motion.div
                key="signed-in"
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-3 px-4 py-3.5"
                style={{
                  background: "rgba(66,133,244,0.07)",
                  border: "1px solid rgba(66,133,244,0.25)",
                  borderRadius: 16,
                }}
              >
                {/* Google avatar placeholder */}
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: "linear-gradient(135deg, #4285F4, #34A853)",
                    fontSize: 16,
                    fontWeight: 700,
                    color: "white",
                  }}
                >
                  R
                </div>
                <div className="flex-1 min-w-0">
                  <span
                    className="block"
                    style={{ color: "#f7f8f8", fontSize: 13, fontWeight: 600 }}
                  >
                    rahul.iitb@gmail.com
                  </span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <Check size={10} color="#34A853" strokeWidth={2.5} />
                    <span style={{ color: "#34A853", fontSize: 11 }}>Google account connected</span>
                  </div>
                </div>
                <div
                  className="px-2.5 py-1"
                  style={{
                    background: "rgba(52,168,83,0.12)",
                    border: "1px solid rgba(52,168,83,0.25)",
                    borderRadius: 8,
                  }}
                >
                  <span style={{ color: "#34A853", fontSize: 10, fontWeight: 700 }}>LINKED</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!googleConnected && (
            <p style={{ color: "#8a8f98", fontSize: 11, marginTop: 8, textAlign: "center", lineHeight: 1.5 }}>
              Connect your Google account to import Gmail and Calendar data into KRNL.
            </p>
          )}
        </div>

        {/* Block 1: Connections */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <Shield size={13} color="#8a8f98" strokeWidth={2} />
            <span style={{ color: "#8a8f98", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Connected Accounts
            </span>
          </div>

          {/* Connected Account */}
          <div
            className="flex items-center gap-3 px-4 py-3.5 mb-2"
            style={{
              background: "#1c1c21",
              border: "1px solid #2d2d34",
              borderRadius: 16,
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}
            >
              <Mail size={18} color="#10b981" strokeWidth={1.8} />
            </div>
            <div className="flex-1 min-w-0">
              <span
                className="block truncate"
                style={{ color: "#f7f8f8", fontSize: 13, fontWeight: 600 }}
              >
                ldap_username@iitb.ac.in
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: "#10b981", boxShadow: "0 0 5px #10b981" }}
                />
                <RefreshCw size={10} color="#10b981" strokeWidth={2} />
                <span style={{ color: "#10b981", fontSize: 11 }}>Synced 2m ago</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div
                className="px-2.5 py-1"
                style={{
                  background: "rgba(16,185,129,0.1)",
                  border: "1px solid rgba(16,185,129,0.25)",
                  borderRadius: 8,
                }}
              >
                <span style={{ color: "#10b981", fontSize: 10, fontWeight: 700 }}>IITB</span>
              </div>
              <ChevronRight size={14} color="#2d2d34" strokeWidth={2} />
            </div>
          </div>

          {/* Add Gmail */}
          <motion.button
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center justify-center gap-2.5 py-4"
            style={{
              background: "transparent",
              border: "1.5px dashed #2d2d34",
              borderRadius: 16,
            }}
          >
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center"
              style={{ background: "#1c1c21", border: "1px solid #2d2d34" }}
            >
              <Plus size={14} color="#8a8f98" strokeWidth={2} />
            </div>
            <span style={{ color: "#8a8f98", fontSize: 13 }}>Add Gmail Account</span>
          </motion.button>
        </div>

        {/* Block 2: Career Track Preferences */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <Info size={13} color="#8a8f98" strokeWidth={2} />
            <span style={{ color: "#8a8f98", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Career Track
            </span>
          </div>

          <div
            className="px-4 py-4"
            style={{
              background: "#1c1c21",
              border: "1px solid #2d2d34",
              borderRadius: 16,
            }}
          >
            <p style={{ color: "#8a8f98", fontSize: 12, marginBottom: 12, lineHeight: 1.5 }}>
              KRNL surfaces relevant opportunities and filters emails based on your selected tracks.
            </p>
            <div className="flex flex-wrap gap-2">
              {tracks.map((track) => {
                const active = selectedTracks.includes(track);
                return (
                  <motion.button
                    key={track}
                    whileTap={{ scale: 0.93 }}
                    onClick={() => toggleTrack(track)}
                    className="px-4 py-1.5"
                    style={{
                      borderRadius: 24,
                      background: active ? "rgba(99,102,241,0.18)" : "transparent",
                      border: active ? "1px solid rgba(99,102,241,0.5)" : "1px solid #2d2d34",
                      color: active ? "#818cf8" : "#8a8f98",
                      fontSize: 13,
                      fontWeight: active ? 600 : 400,
                    }}
                  >
                    {track}
                  </motion.button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Block 3: System Details */}
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <Info size={13} color="#8a8f98" strokeWidth={2} />
            <span style={{ color: "#8a8f98", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              System
            </span>
          </div>

          <div
            className="px-4 py-4"
            style={{
              background: "#1c1c21",
              border: "1px solid #2d2d34",
              borderRadius: 16,
            }}
          >
            {[
              { label: "Version", value: "KRNL v0.9.2 beta" },
              { label: "Sync frequency", value: "Every 5 minutes" },
              { label: "AI Model", value: "claude-sonnet-4-6" },
              { label: "Data stored", value: "On-device only" },
            ].map((item) => (
              <div
                key={item.label}
                className="flex items-center justify-between py-2.5"
                style={{ borderBottom: "1px solid #2d2d34" }}
              >
                <span style={{ color: "#8a8f98", fontSize: 13 }}>{item.label}</span>
                <span style={{ color: "#f7f8f8", fontSize: 13, fontWeight: 500 }}>{item.value}</span>
              </div>
            ))}
            <div className="flex items-center justify-between py-2.5">
              <span style={{ color: "#8a8f98", fontSize: 13 }}>Last full sync</span>
              <span style={{ color: "#f7f8f8", fontSize: 13, fontWeight: 500 }}>Just now</span>
            </div>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle size={13} color="#ef4444" strokeWidth={2} />
            <span style={{ color: "#ef4444", fontSize: 12, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
              Danger Zone
            </span>
          </div>

          {showDangerConfirm ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="px-4 py-4"
              style={{
                background: "rgba(239,68,68,0.06)",
                border: "1px solid rgba(239,68,68,0.3)",
                borderRadius: 16,
              }}
            >
              <p style={{ color: "#f87171", fontSize: 13, marginBottom: 12, lineHeight: 1.5 }}>
                This will disconnect all accounts and permanently wipe all locally stored email data. This cannot be undone.
              </p>
              <div className="flex gap-2">
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setShowDangerConfirm(false)}
                  className="flex-1 py-2.5"
                  style={{
                    background: "#1c1c21",
                    border: "1px solid #2d2d34",
                    borderRadius: 10,
                    color: "#8a8f98",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  Cancel
                </motion.button>
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  className="flex-1 py-2.5"
                  style={{
                    background: "rgba(239,68,68,0.15)",
                    border: "1px solid rgba(239,68,68,0.4)",
                    borderRadius: 10,
                    color: "#f87171",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  Confirm Wipe
                </motion.button>
              </div>
            </motion.div>
          ) : (
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={() => setShowDangerConfirm(true)}
              className="w-full py-4 flex items-center justify-center gap-2.5"
              style={{
                background: "rgba(239,68,68,0.08)",
                border: "1px solid rgba(239,68,68,0.25)",
                borderRadius: 16,
              }}
            >
              <AlertTriangle size={16} color="#f87171" strokeWidth={2} />
              <span style={{ color: "#f87171", fontSize: 14, fontWeight: 600 }}>
                Disconnect Account & Wipe Data
              </span>
            </motion.button>
          )}
        </div>
      </div>
    </div>
  );
}
