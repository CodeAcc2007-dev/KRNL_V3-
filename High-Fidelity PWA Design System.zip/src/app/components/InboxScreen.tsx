import { useState } from "react";
import { Menu, Calendar, AlertCircle, Tag, Star } from "lucide-react";
import { motion } from "motion/react";

interface InboxScreenProps {
  onOpenSettings: () => void;
}

const filters = ["Important", "Opportunities", "Announcement", "Academic"];

const emails = [
  {
    id: 1,
    initial: "A",
    sender: "CS 302: Quiz 1",
    summary: "Rescheduled to Friday, October 12th — room change to LT 101",
    deadline: "Oct 12",
    priority: "High",
    category: "Quiz",
    time: "2h",
    unread: true,
  },
  {
    id: 2,
    initial: "P",
    sender: "Prof. Sharma",
    summary: "Project milestone 2 submission extended by 48 hours due to...",
    deadline: "Oct 15",
    priority: "Med",
    category: "Project",
    time: "4h",
    unread: true,
  },
  {
    id: 3,
    initial: "C",
    sender: "Career Cell IITB",
    summary: "Goldman Sachs internship applications closing — 3 slots left",
    deadline: "Oct 14",
    priority: "High",
    category: "Intern",
    time: "6h",
    unread: false,
  },
  {
    id: 4,
    initial: "H",
    sender: "HSS 102",
    summary: "Reading assignment posted: Chapters 4–6, quiz next Monday",
    deadline: "Oct 16",
    priority: "Med",
    category: "HW",
    time: "1d",
    unread: false,
  },
  {
    id: 5,
    initial: "I",
    sender: "Inter-IIT Tech Meet",
    summary: "Registration deadline extended — team of 4 required, all branches",
    deadline: "Oct 18",
    priority: "Low",
    category: "Event",
    time: "1d",
    unread: false,
  },
  {
    id: 6,
    initial: "M",
    sender: "MA 214: Numerics",
    summary: "Tutorial sheet 5 solutions uploaded; midsem syllabus finalized",
    deadline: "—",
    priority: "Low",
    category: "Info",
    time: "2d",
    unread: false,
  },
];

const priorityColor = {
  High: "#ef4444",
  Med: "#f59e0b",
  Low: "#8a8f98",
};

export function InboxScreen({ onOpenSettings }: InboxScreenProps) {
  const [activeFilter, setActiveFilter] = useState("Important");

  return (
    <div className="flex flex-col h-full" style={{ background: "#08090a" }}>
      {/* Safe area top */}
      <div style={{ paddingTop: 48 }}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 pb-4">
          <button
            className="flex items-center justify-center w-9 h-9 rounded-xl"
            style={{ background: "#1c1c21", border: "1px solid #2d2d34" }}
          >
            <Menu size={18} color="#8a8f98" strokeWidth={1.8} />
          </button>

          <span
            className="tracking-[0.2em] uppercase"
            style={{ color: "#f7f8f8", fontSize: 17, fontWeight: 700, letterSpacing: "0.18em" }}
          >
            KRNL
          </span>

          <button onClick={onOpenSettings} className="relative">
            <div
              className="flex items-center justify-center w-9 h-9 rounded-full"
              style={{ background: "#6366f1", fontWeight: 700, color: "white", fontSize: 15 }}
            >
              R
            </div>
            <div
              className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full"
              style={{ background: "#10b981", border: "2px solid #08090a" }}
            />
          </button>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 px-4 pb-4 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {filters.map((f) => {
            const active = f === activeFilter;
            return (
              <motion.button
                key={f}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveFilter(f)}
                className="flex items-center gap-1.5 whitespace-nowrap px-4 py-1.5 flex-shrink-0"
                style={{
                  borderRadius: 24,
                  background: active ? "rgba(99,102,241,0.18)" : "transparent",
                  border: active ? "1px solid rgba(99,102,241,0.4)" : "1px solid #2d2d34",
                  color: active ? "#f7f8f8" : "#8a8f98",
                  fontSize: 13,
                  fontWeight: active ? 600 : 400,
                }}
              >
                {active && <Star size={11} fill="#f7f8f8" color="#f7f8f8" />}
                {f}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto px-4 flex flex-col gap-2" style={{ scrollbarWidth: "none", paddingBottom: 110 }}>
        {emails.map((email, i) => (
          <motion.div
            key={email.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05, duration: 0.3 }}
            className="flex items-center gap-3 px-3 py-3.5 cursor-pointer"
            style={{
              background: "#1c1c21",
              border: "1px solid #2d2d34",
              borderRadius: 16,
            }}
          >
            {/* Avatar */}
            <div
              className="flex items-center justify-center flex-shrink-0 rounded-full"
              style={{
                width: 40,
                height: 40,
                background: "#6366f1",
                color: "white",
                fontSize: 15,
                fontWeight: 700,
              }}
            >
              {email.initial}
            </div>

            {/* Text Stack */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span
                  className="truncate"
                  style={{
                    color: email.unread ? "#f7f8f8" : "#a0a5b0",
                    fontSize: 14,
                    fontWeight: email.unread ? 600 : 500,
                  }}
                >
                  {email.sender}
                </span>
                {email.unread && (
                  <div
                    className="flex-shrink-0 w-1.5 h-1.5 rounded-full"
                    style={{ background: "#6366f1" }}
                  />
                )}
              </div>
              <span
                className="block truncate mt-0.5"
                style={{ color: "#8a8f98", fontSize: 12, lineHeight: 1.4 }}
              >
                {email.summary}
              </span>
            </div>

            {/* Metadata icon group */}
            <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
              {/* Time */}
              <span style={{ color: "#8a8f98", fontSize: 10 }}>{email.time}</span>

              {/* Deadline chip */}
              <div
                className="flex items-center gap-1 px-1.5 py-0.5"
                style={{
                  background: "rgba(239,68,68,0.1)",
                  borderRadius: 6,
                  border: "1px solid rgba(239,68,68,0.2)",
                }}
              >
                <Calendar size={9} color="#ef4444" strokeWidth={2} />
                <span style={{ color: "#ef4444", fontSize: 9, fontWeight: 600 }}>
                  {email.deadline}
                </span>
              </div>

              {/* Priority */}
              <div className="flex items-center gap-1">
                <AlertCircle
                  size={10}
                  color={priorityColor[email.priority as keyof typeof priorityColor]}
                  strokeWidth={2}
                />
                <span
                  style={{
                    color: priorityColor[email.priority as keyof typeof priorityColor],
                    fontSize: 9,
                    fontWeight: 600,
                  }}
                >
                  {email.priority}
                </span>
              </div>

              {/* Category */}
              <div className="flex items-center gap-1">
                <Tag size={9} color="#8a8f98" strokeWidth={2} />
                <span style={{ color: "#8a8f98", fontSize: 9 }}>{email.category}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
