import { useState } from "react";
import { Clock, ChevronRight, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

const filters = ["Overdue", "This Week", "Later"];

const deadlines = [
  {
    id: 1,
    course: "HSS 102 Assignment",
    type: "Assignment",
    due: "Due in 4 hours",
    urgency: "critical",
    accentColor: "#ef4444",
    borderColor: "rgba(239,68,68,0.35)",
    bgAccent: "rgba(239,68,68,0.06)",
    dotColor: "#ef4444",
    done: false,
    badge: "4h left",
    badgeBg: "rgba(239,68,68,0.15)",
    badgeColor: "#f87171",
  },
  {
    id: 2,
    course: "CS 213 Lab Submission",
    type: "Lab",
    due: "Due Tomorrow, 11:59 PM",
    urgency: "warning",
    accentColor: "#f59e0b",
    borderColor: "rgba(245,158,11,0.35)",
    bgAccent: "rgba(245,158,11,0.06)",
    dotColor: "#f59e0b",
    done: false,
    badge: "Tomorrow",
    badgeBg: "rgba(245,158,11,0.15)",
    badgeColor: "#fbbf24",
  },
  {
    id: 3,
    course: "Inter-IIT Registration",
    type: "Event",
    due: "Due in 5 days",
    urgency: "normal",
    accentColor: "#2d2d34",
    borderColor: "#2d2d34",
    bgAccent: "transparent",
    dotColor: "#8a8f98",
    done: false,
    badge: "5 days",
    badgeBg: "rgba(141,145,152,0.12)",
    badgeColor: "#8a8f98",
  },
  {
    id: 4,
    course: "MA 214 Tutorial Sheet 5",
    type: "Homework",
    due: "Due in 6 days",
    urgency: "normal",
    accentColor: "#2d2d34",
    borderColor: "#2d2d34",
    bgAccent: "transparent",
    dotColor: "#8a8f98",
    done: false,
    badge: "6 days",
    badgeBg: "rgba(141,145,152,0.12)",
    badgeColor: "#8a8f98",
  },
  {
    id: 5,
    course: "CS 302 Project Milestone",
    type: "Project",
    due: "Due Oct 18, 11:59 PM",
    urgency: "normal",
    accentColor: "#2d2d34",
    borderColor: "#2d2d34",
    bgAccent: "transparent",
    dotColor: "#8a8f98",
    done: true,
    badge: "Done",
    badgeBg: "rgba(16,185,129,0.12)",
    badgeColor: "#10b981",
  },
];

export function DeadlinesScreen() {
  const [activeFilter, setActiveFilter] = useState("This Week");
  const [checked, setChecked] = useState<number[]>([5]);

  const toggleCheck = (id: number) => {
    setChecked((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="flex flex-col h-full" style={{ background: "#08090a" }}>
      <div style={{ paddingTop: 48 }}>
        {/* Header */}
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-0.5">
            <span
              style={{ color: "#f7f8f8", fontSize: 22, fontWeight: 700 }}
            >
              Deadlines
            </span>
            <div
              className="flex items-center gap-1.5 px-3 py-1"
              style={{
                background: "rgba(99,102,241,0.12)",
                borderRadius: 20,
                border: "1px solid rgba(99,102,241,0.25)",
              }}
            >
              <Clock size={11} color="#818cf8" strokeWidth={2} />
              <span style={{ color: "#818cf8", fontSize: 11, fontWeight: 600 }}>
                3 due this week
              </span>
            </div>
          </div>
          <span style={{ color: "#8a8f98", fontSize: 13 }}>
            Stay ahead of your schedule
          </span>
        </div>

        {/* Filter Pills */}
        <div className="flex gap-2 px-4 pb-4 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {filters.map((f) => {
            const active = f === activeFilter;
            return (
              <motion.button
                key={f}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveFilter(f)}
                className="flex items-center gap-1.5 whitespace-nowrap px-4 py-1.5 flex-shrink-0"
                style={{
                  borderRadius: 24,
                  background: active ? "rgba(99,102,241,0.18)" : "transparent",
                  border: active ? "1px solid rgba(99,102,241,0.4)" : "1px solid #2d2d34",
                  color: active ? "#f7f8f8" : "#8a8f98",
                  fontSize: 13,
                  fontWeight: active ? 600 : 400,
                }}
              >
                {f}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Timeline List */}
      <div className="flex-1 overflow-y-auto px-4" style={{ scrollbarWidth: "none", paddingBottom: 110 }}>
        {/* Timeline connector */}
        <div className="relative">
          {/* Left timeline line */}
          <div
            className="absolute left-[19px] top-4 bottom-4 w-px"
            style={{ background: "linear-gradient(to bottom, #2d2d34, transparent)" }}
          />

          <div className="flex flex-col gap-3">
            {deadlines.map((item, i) => {
              const isDone = checked.includes(item.id);
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.3 }}
                  className="flex gap-3 items-start"
                >
                  {/* Timeline dot */}
                  <div className="flex flex-col items-center flex-shrink-0 pt-3.5">
                    <div
                      className="w-2.5 h-2.5 rounded-full z-10"
                      style={{
                        background: isDone ? "#10b981" : item.dotColor,
                        boxShadow: isDone
                          ? "0 0 8px rgba(16,185,129,0.5)"
                          : item.urgency === "critical"
                          ? "0 0 8px rgba(239,68,68,0.5)"
                          : "none",
                      }}
                    />
                  </div>

                  {/* Card */}
                  <div
                    className="flex-1 flex items-center justify-between px-4 py-3.5"
                    style={{
                      background: isDone ? "rgba(16,185,129,0.05)" : item.bgAccent || "#1c1c21",
                      border: `1px solid ${isDone ? "rgba(16,185,129,0.25)" : item.borderColor}`,
                      borderRadius: 16,
                      opacity: isDone ? 0.7 : 1,
                    }}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          style={{
                            color: isDone ? "#8a8f98" : "#f7f8f8",
                            fontSize: 14,
                            fontWeight: 600,
                            textDecoration: isDone ? "line-through" : "none",
                          }}
                        >
                          {item.course}
                        </span>
                        <span
                          className="px-2 py-0.5"
                          style={{
                            background: isDone ? "rgba(16,185,129,0.12)" : item.badgeBg,
                            color: isDone ? "#10b981" : item.badgeColor,
                            fontSize: 10,
                            fontWeight: 700,
                            borderRadius: 8,
                          }}
                        >
                          {isDone ? "Done" : item.badge}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Clock size={10} color="#8a8f98" strokeWidth={2} />
                        <span style={{ color: "#8a8f98", fontSize: 12 }}>
                          {isDone ? "Completed" : item.due}
                        </span>
                      </div>
                      <span
                        className="mt-1 inline-block px-2 py-0.5"
                        style={{
                          background: "#2d2d34",
                          color: "#8a8f98",
                          fontSize: 10,
                          borderRadius: 6,
                        }}
                      >
                        {item.type}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 ml-3">
                      <motion.button
                        whileTap={{ scale: 0.88 }}
                        onClick={() => toggleCheck(item.id)}
                        className="flex items-center justify-center w-7 h-7 rounded-full"
                        style={{
                          background: isDone ? "rgba(16,185,129,0.15)" : "rgba(45,45,52,0.8)",
                          border: `1.5px solid ${isDone ? "#10b981" : "#2d2d34"}`,
                        }}
                      >
                        <CheckCircle2
                          size={14}
                          color={isDone ? "#10b981" : "#8a8f98"}
                          strokeWidth={2}
                        />
                      </motion.button>
                      <ChevronRight size={14} color="#2d2d34" strokeWidth={2} />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
